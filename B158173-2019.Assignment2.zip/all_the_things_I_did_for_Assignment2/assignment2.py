#!/usr/bin/python3
#BPSM Assignment2

import os
import subprocess
from datetime import datetime
from datetime import date

# Ask the system to run the clear command
os.system('clear')
# Datetime object containing current date and time
now = datetime.now()
today = date.today()

# Print date and time in format: dd/mm/YY H:M:S
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
print("Local time: ", dt_string)

# Greeting at the beginning
print("Welcome!")


# Define a function
# Because it may not get expected result and need to search again
# It is necessary for user to input the protein name, taxonomic group and choices for partial and predicted item.
def search():
    # User need to input
    taxon = input("\nPlease type the taxonomic group you want: \n")
    protein = input("\nPlease type the protein family you want: \n")
    # User will decide partial or not
    Partial = input("\nThere are some partial sequences on NCBI, only type 'Y' for getting them: \n")
    if Partial == 'Y':
        #Default is yes, so it doesn't need anything else
        partial = ''
    else:
        #Add a partial requirement based on the search format
        partial = "| efilter -query 'NOT Partial'"
    # User will decide preditced or not
    Predicted = input("\nThere are some predicted sequences on NCBI, only type 'Y' for getting them: \n")
    if Predicted == 'Y':
        #Default is yes, so it doesn't need anything else
        predicted = ''
    else:
        #Add a predicted requirement based on the search format
        predicted = "| efilter -query 'NOT PREDICTED'"
    #print the user input
    print(f"\n{protein} in {taxon}, with partial choice {Partial} and predicted choice {Predicted} is searching now, please wait...\n")

    # Here is some difference on searching single word or multiple words, for multiple words, it need parentheses
    if ' ' in protein:
        pro = f"'({protein})'"
        #To call variables when naming, especially for
        protein = protein.replace(' ','_')
    else:
        pro = protein

    # The subprocess module provides a consistent interface to creating and working with additional processes.
    # check_output could return a value
    # Here use a pipe, to count the '>' as number of sequences
    number = subprocess.check_output(f"esearch -db protein -query {pro}[PROT] | efilter -query '{taxon}'[ORGN] {partial} {predicted} | efetch -format fasta | grep '>' | wc -l", shell=True)
    # the type of return number is bytes, so it need be decoded remove other things
    number = number.decode().replace('\n', '')
    # return number,taxon, pro, protein, partial, predicted for later using
    return number, taxon, pro, protein, partial, predicted
# call the function
number, taxon, pro, protein, partial, predicted = search()


# Classify results
# the limit of number of sequences is 10000
if int(number) > 10000:
    #print result and need user to choose search again or not
    choice = input("\nRESULT: Ooh! Sorry for waiting for a long time. There are more than 10000 species for your search, please type more specific. Would you want to try again? Only 'Y' for search again, other for exit: \n")
    if choice == 'Y':
        # call the function again
        number, taxon, pro, protein, partial, predicted = search()
    else:
        exit()
# there is no result
elif int(number) == 0:
    #print result and need user to choose search again or not
    zero = input("\nRESULT: Ahh! There are no result for your search. Please type the scientific name? Would you want to try again? Only 'Y' for search again, other for exit: \n")
    if zero == 'Y':
        #call the function again
        number, taxon, pro, protein, partial, predicted = search()
    else:
        exit()
# Expected result
elif 0 < int(number) < 10000:
    # print the result
    print("\nRESULT:", protein, "in", taxon, "has", number, "species")
    cont = input(f"\nI will download the sequences and the output filename is {protein}_{taxon}.fa. Only type 'Y' for continue: \n")
    # User choose continue
    if cont == 'Y':
        # create work directory on current path, name is protein_taxon_date
        pwd = os.getcwd()
        workdir = os.path.join(pwd, f'{protein}_{taxon}_{today}')
        if not os.path.exists(workdir):
            os.mkdir(workdir)
        os.chdir(workdir)
        print(f"\nYour work directory is {protein}_{taxon}_{today}\n")

        # call the function to download target file
        subprocess.call(f"esearch -db protein -query {pro}[PROT] | efilter -query '{taxon}'[ORGN] {partial} {predicted} | efetch -format fasta >{protein}_{taxon}.fa", shell=True)
        print(f"\nThe origianl fasta format filename is {protein}_{taxon}.fa\n")
        #create a dictionary for the original file: key-protein id, value-fasta format for each sequences data
        faDic = {}
        with open(f'{protein}_{taxon}.fa') as f:
            # split by '>' for part
            parts = f.read().split('>')
            for part in parts:
                if not part:
                    continue
                lines = part.splitlines()
                # first is the protein id
                key = lines[0].split(' ')[0]
                # lost '>'
                faDic[key] = '>'+part
    else:
        print("\nBye!")
        exit()



# continue blast or exit
contia = input("\nI will do some blast later. Would you like to continue? Only 'N' for exit\n")
if contia == 'N':
    print("\nBye!")
    exit()

#clustalo to align
print("\nclustalo for all original sequences...\n")
subprocess.call (f"clustalo -i {protein}_{taxon}.fa >{protein}_{taxon}.clustalo", shell = True)
print(f"\nAligned sequences filename is {protein}_{taxon}.clustalo\n")

#Create a consensus sequence from a multiple alignment
print("\ncreate a consensus sequence from a multiple alignment...\n")
subprocess.call (f"cons -sequence {protein}_{taxon}.clustalo -outseq {protein}_{taxon}_cons.fa", shell = True)
print("\nHere is the consensus sequence\n")
# Have a look at consensus sequence
subprocess.call (f"cat {protein}_{taxon}_cons.fa", shell = True)
print(f"\nAligned sequences filename is {protein}_{taxon}_cons.fa\n")

#make a database for blast
print(f"\nWe will make a database {protein}_{taxon}db as preparation for blast...\n")
subprocess.call (f"makeblastdb -in {protein}_{taxon}.fa -dbtype prot -out {protein}_{taxon}db", shell = True)

#blast with cons file in {protein}_{taxon}databases
print(f"\nWe will blast with cons file in {protein}_{taxon}databases...\n")
subprocess.call (f"blastp -db {protein}_{taxon}db -query {protein}_{taxon}_cons.fa > {protein}_{taxon}_blast.out", shell = True)
print(f"\nThe blast output filename is {protein}_{taxon}_blast.out\n")

#create a list for the blast output file : bit scores from high to low
blastList = []
with open(f'{protein}_{taxon}_blast.out') as f:
    content = f.read()
    # slice for the result table
    startPosition = content.find('Sequences producing significant alignments')
    startPosition = content.find('\n',startPosition)
    # before '>'
    endPosition = content.find('>',startPosition)
    # then it will be a seperate table
    portion = content[startPosition:endPosition]

    for line in portion.splitlines():
        if not line.strip():
        	continue
        #extract the protein id
        idStr = line.strip().split(' ')[0]
        #append to the list until 250
        blastList.append(idStr)
        #limit 250
        if len(blastList)==250:
            break

print("\nHere is a brief table(<250 protein id) for the blastp result, and it is sorted by bits score\n")
#print list for the blastp result
with open(f'{protein}_{taxon}_blast.out') as f:
    content = f.read()
    #find the startPosition and endPosition
    pos1 = content.find('Sequences producing significant alignments:')
    pos2 = content.find('\n',pos1)
    pos3 = content.find('\n>',pos1)
    header = content[pos2:pos3]
    print('''                                                                      Score     E
Sequs producing significant alignments:                          (Bits)  Value''')
    for idx,line in enumerate(header.splitlines()):
        #print <=250 sequences results
        if idx>=250:
            break
        print(line)

#create a new file with sorted 250 value from high bits score to low
#use the value in list(blastList) as key to search in dictionary(faDic) get sequences
print(f"\ncreate {protein}_{taxon}.sorted: sorted bits score sequences in fasta format...\n")
f = open(f"{protein}_{taxon}.sorted","w+")
for i in blastList:
    f.write(faDic.get(i))
f.close()

#create a dictionary(motifDic) and
#preparation for motif search
motifDic = {}
with open(f'{protein}_{taxon}.sorted') as f:
    parts = f.read().split('>')
    for part in parts:
        if not part:
            continue
        lines = part.splitlines()
        #key is sorted protein id by bits score from high to low
        #value is fasta format for each sequence
        key = lines[0].split(' ')[0]
        motifDic[key] = '>'+part



# continue plotcon or exit
contib = input("\nI will plot conservation of a sequence alignment. Would you like to continue? Only 'N' for exit\n")
if contib == 'N':
    print("\nBye!")
    exit()

#generate conservation plot for all sequences
print("\ncreate a conservation plot for all aligned sequences...\nif you want to save the file, you can type '10' for winsize and 'svg' for graph(necessary)\nif you don't want to save it, just 'Enter' for winsize or graph\n")
subprocess.call (f"plotcon -sequences {protein}_{taxon}.clustalo", shell = True)

#generate conservation plot for 250 score sorted sequences
if int(number) > 250:
#clustalo the sorted sequences file to align
    print("\nclustalo for sorted sequences...\n")
    subprocess.call (f"clustalo -i {protein}_{taxon}.sorted >{protein}_{taxon}_sorted.clustalo", shell = True)
#generate conservation plot input-*.clustalo !!ask user save files or not
    print("\ncreate a conservation plot for these sorted aligned 250 sequences...\nif you want to save the file, you can type '10' for winsize and 'png' for graph(necessary)\nif you don't want to save it, just 'Enter' for winsize or graph\n")
    subprocess.call (f"plotcon -sequences {protein}_{taxon}_sorted.clustalo", shell = True)



#continue for scan motif or not
contic = input("\nI will scan protein sequences with motif on Prosite. Would you like to continue? Only 'N' for exit\n")
if contic == 'N':
    print("\nBye!")
    exit()

print("\nThere are 2 choices for you to choose protein sequence :\nchoice1: choose the highest bits score sequence\nchoice2: I will display the bits score table, and enter the protein ID you want")
choice = input("choice 1:type'1'\nchoice 2:type'2'\n")

#choice 1
if choice == '1':
    #get the firstid in the score table
    seq = list(motifDic.values())[0]
    firstid = list(motifDic.keys())[0]
    #write a new file with the firstid fasta format sequence
    f = open(f"{firstid}_seq.fa","w+")
    f.write(seq)
    f.close()
    subprocess.call(f"patmatmotifs -sequence {firstid}_seq.fa -outfile {firstid}_seq.report ", shell = True)
    print(f"\n{firstid}_seq.report is generating...\n")
    with open(f'{firstid}_seq.report') as f:
        content = f.read()
        #'Motif' only exists in the sequence file which has motif
        result = content.find('Motif')
        if result == -1:
            print(f"\nThere is no motif in {firstid}\n")
        else:
            motif = subprocess.check_output(f"grep 'Motif' {firstid}_seq.report", shell=True)
            motif = motif.decode().replace('\n', '')
            print("\nRESULT:\n", motif)

#choice 2
if choice == '2':
    #define a function for multiple searching for motif
    def choicetwo():
        #display the blast output table
        with open(f'{protein}_{taxon}_blast.out') as f:
            content = f.read()
            pos1 = content.find('Sequences producing significant alignments:')
            pos2 = content.find('\n',pos1)
            pos3 = content.find('\n>',pos1)
            header = content[pos2:pos3]
            print('''                                                                      Score     E
Sequs producing significant alignments:                          (Bits)  Value''')
            for idx,line in enumerate(header.splitlines()):
                if idx>=250:
                    break
                print(line)

        iduser = input("\nprotein id you want to scan with motif:\n")
        seq = str(motifDic.get(f"{iduser}"))
        #write a new file with the target fasta format sequence
        f = open(f"{iduser}_seq.fa","w+")
        f.write(seq)
        f.close()

        print(f"\n{iduser}_seq.report is generating...\n")
        subprocess.call(f"patmatmotifs -sequence {iduser}_seq.fa -outfile {iduser}_motif.report", shell = True)
        return iduser
    iduser = choicetwo()
    #'Motif' only exists in the sequence file which has motif
    with open(f'{iduser}_motif.report') as f:
        content = f.read()
        result = content.find('Motif')
        if result == -1:
            motifagain = input(f"There is no motif in {iduser}, would you like try another sequence? Y")
            if motifagain == 'Y':
                iduser = choicetwo()
        else:
            motif = subprocess.check_output(f"grep 'Motif' {iduser}_motif.report", shell=True)
            motif = motif.decode().replace('\n', '\t')
            print("\nRESULT:\n\t",motif)



#continue GO or not
contid = input("\nI will search motif name for gene ontology. Would you like to continue? 'N' for exit\n")
if contid == 'N':
    print("Bye!")
    exit()

#further GO analysis
go = input("\nmotif name you want to search for gene ontology: \n")
print(f"\ngenerating and displaying {go}.go...\n")
subprocess.call(f"goname -query {go} -outfile {go} | cat {go}.go", shell = True)
print("\nIf there are some error, you may type a wrong motif name\n")
print("Thank you for using.")
